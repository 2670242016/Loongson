
#include <stdio.h>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>
#include <math.h>
#include <cmath>

#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/i2c-dev.h>
// #include <windows.h>

#define IIC_ADDR_RECEIVER 0x08
#define IIC_DATA_LENGTH 8
#define IIC_DATA_DIRECTION 0

#define image_h	120//图像高度
#define image_w	160//图像宽度

#define white_pixel	255
#define black_pixel	0

#define bin_jump_num	1//跳过的点数
#define border_max	image_w-2 //边界最大值
#define border_min	1	//边界最小值	

#define USE_num	image_h*3

#define threshold_max	255*5//此参数可根据自己的需求调节
#define threshold_min	255*2//此参数可根据自己的需求调节

using namespace std;
using namespace cv;

typedef   signed          char int8;
typedef   signed short     int int16;
typedef   signed           int int32;
typedef unsigned          char uint8;
typedef unsigned short     int uint16;
typedef unsigned           int uint32;


uint8 original_image[image_h][image_w];
uint8 image_thereshold;//图像分割阈值

uint8 bin_image[image_h][image_w];//图像数组

uint16 start_point_l[2] = { 0 };//左边起点的x，y值
uint16 start_point_r[2] = { 0 };//右边起点的x，y值

uint16 points_l[(uint16)USE_num][2] = { {  0 } };//左线
uint16 points_r[(uint16)USE_num][2] = { {  0 } };//右线
uint16 dir_r[(uint16)USE_num] = { 0 };//用来存储右边生长方向
uint16 dir_l[(uint16)USE_num] = { 0 };//用来存储左边生长方向
uint16 data_stastics_l = 0;//统计左边找到点的个数
uint16 data_stastics_r = 0;//统计右边找到点的个数
uint16 hightest = 0;//最高点

uint16 l_border[image_h];//左线数组
uint16 r_border[image_h];//右线数组
uint16 center_line[image_h];//中线数组


// 求绝对值
static int my_abs(int value)
{
	if (value >= 0) return value;
	else return -value;
}

// 限幅
static int16 limit_a_b(int16 x, int a, int b)
{
	if (x < a) x = a;
	if (x > b) x = b;
	return x;
}

// 获取图像
static void Get_image(Mat img)
{
	for (int i = 0; i < image_h; i++) {
		for (int j = 0; j < image_w; j++) {
			original_image[i][j] = img.at<unsigned char>(i, j);
			// printf("第%d行 第%d列 灰度值:%d\n", i, j, original_image[i][j]);
		}
	}
}

// 大津法（OTSU）是一种确定图像二值化分割阈值的算法
// 输入：图像数组，图像宽度，图像高度
static uint8 otsuThreshold(uint8* image, uint16 col, uint16 row)
{
#define GrayScale 256
	uint16 Image_Width = col;
	uint16 Image_Height = row;
	int X; uint16 Y;
	uint8* data = image;
	int HistGram[GrayScale] = { 0 };

	uint32 Amount = 0;
	uint32 PixelBack = 0;
	uint32 PixelIntegralBack = 0;
	uint32 PixelIntegral = 0;
	int32 PixelIntegralFore = 0;
	int32 PixelFore = 0;
	double OmegaBack = 0, OmegaFore = 0, MicroBack = 0, MicroFore = 0, SigmaB = 0, Sigma = 0; // 类间方差;
	uint8 MinValue = 0, MaxValue = 0;
	uint8 Threshold = 0;


	for (Y = 0; Y < Image_Height; Y++) //Y<Image_Height改为Y =Image_Height；以便进行 行二值化
	{
		//Y=Image_Height;
		for (X = 0; X < Image_Width; X++)
		{
			HistGram[(int)data[Y * Image_Width + X]]++; //统计每个灰度值的个数信息
		}
	}




	for (MinValue = 0; MinValue < 256 && HistGram[MinValue] == 0; MinValue++);        //获取最小灰度的值
	for (MaxValue = 255; MaxValue > MinValue && HistGram[MinValue] == 0; MaxValue--); //获取最大灰度的值

	if (MaxValue == MinValue)
	{
		return MaxValue;          // 图像中只有一个颜色
	}
	if (MinValue + 1 == MaxValue)
	{
		return MinValue;      // 图像中只有二个颜色
	}

	for (Y = MinValue; Y <= MaxValue; Y++)
	{
		Amount += HistGram[Y];        //  像素总数
	}

	PixelIntegral = 0;
	for (Y = MinValue; Y <= MaxValue; Y++)
	{
		PixelIntegral += HistGram[Y] * Y;//灰度值总数
	}
	SigmaB = -1;
	for (Y = MinValue; Y < MaxValue; Y++)
	{
		PixelBack = PixelBack + HistGram[Y];    //前景像素点数
		PixelFore = Amount - PixelBack;         //背景像素点数
		OmegaBack = (double)PixelBack / Amount;//前景像素百分比
		OmegaFore = (double)PixelFore / Amount;//背景像素百分比
		PixelIntegralBack += HistGram[Y] * Y;  //前景灰度值
		PixelIntegralFore = PixelIntegral - PixelIntegralBack;//背景灰度值
		MicroBack = (double)PixelIntegralBack / PixelBack;//前景灰度百分比
		MicroFore = (double)PixelIntegralFore / PixelFore;//背景灰度百分比
		Sigma = OmegaBack * OmegaFore * (MicroBack - MicroFore) * (MicroBack - MicroFore);//g
		if (Sigma > SigmaB)//遍历最大的类间方差g
		{
			SigmaB = Sigma;
			Threshold = (uint8)Y;
		}
	}
	return Threshold;
}

// 二值化
static void turn_to_bin(void)
{
	image_thereshold = otsuThreshold(original_image[0], image_w, image_h);
	for (int i = 0;i < image_h;i++)
	{
		for (int j = 0;j < image_w;j++)
		{
			if (original_image[i][j] > image_thereshold)bin_image[i][j] = white_pixel;
			else bin_image[i][j] = black_pixel;
		}
	}
}

// 获取八邻域起始点
// 输入：起始行
static uint8 get_start_point(uint8 start_row)
{
	int i = 0, l_found = 0, r_found = 0;
	//清零
	start_point_l[0] = 0;//x
	start_point_l[1] = 0;//y

	start_point_r[0] = 0;//x
	start_point_r[1] = 0;//y

	//从中间往左边，先找起点
	for (i = image_w / 2; i > border_min; i--)
	{
		start_point_l[0] = i;//x
		start_point_l[1] = start_row;//y
		if (bin_image[start_row][i] == 255 && bin_image[start_row][i - 1] == 0)
		{
			//printf("找到左边起点image[%d][%d]\n", start_row,i);
			l_found = 1;
			break;
		}
	}

	for (i = image_w / 2; i < border_max; i++)
	{
		start_point_r[0] = i;//x
		start_point_r[1] = start_row;//y
		if (bin_image[start_row][i] == 255 && bin_image[start_row][i + 1] == 0)
		{
			//printf("找到右边起点image[%d][%d]\n",start_row, i);
			r_found = 1;
			break;
		}
	}

	if (l_found && r_found)return 1;
	else {
		//printf("未找到起点\n");
		return 0;
	}

}

// 左右巡线
static void search_l_r(uint16 break_flag, uint8(*image)[image_w], uint16* l_stastic, uint16* r_stastic, uint8 l_start_x, uint8 l_start_y, uint8 r_start_x, uint8 r_start_y, uint8* hightest)
{

	uint8 i = 0, j = 0;

	//左边变量
	uint8 search_filds_l[8][2] = { {  0 } };
	uint8 index_l = 0;
	uint8 temp_l[8][2] = { {  0 } };
	uint8 center_point_l[2] = { 0 };
	uint16 l_data_statics;//统计左边
	//定义八个邻域
	static int8 seeds_l[8][2] = { {0,  1},{-1,1},{-1,0},{-1,-1},{0,-1},{1,-1},{1,  0},{1, 1}, };
	//{-1,-1},{0,-1},{+1,-1},
	//{-1, 0},	     {+1, 0},
	//{-1,+1},{0,+1},{+1,+1},
	//这个是顺时针

	//右边变量
	uint8 search_filds_r[8][2] = { {  0 } };
	uint8 center_point_r[2] = { 0 };//中心坐标点
	uint8 index_r = 0;//索引下标
	uint8 temp_r[8][2] = { {  0 } };
	uint16 r_data_statics;//统计右边
	//定义八个邻域
	static int8 seeds_r[8][2] = { {0,  1},{1,1},{1,0}, {1,-1},{0,-1},{-1,-1}, {-1,  0},{-1, 1}, };
	//{-1,-1},{0,-1},{+1,-1},
	//{-1, 0},	     {+1, 0},
	//{-1,+1},{0,+1},{+1,+1},
	//这个是逆时针

	l_data_statics = *l_stastic;//统计找到了多少个点，方便后续把点全部画出来
	r_data_statics = *r_stastic;//统计找到了多少个点，方便后续把点全部画出来

	//第一次更新坐标点  将找到的起点值传进来
	center_point_l[0] = l_start_x;//x
	center_point_l[1] = l_start_y;//y
	center_point_r[0] = r_start_x;//x
	center_point_r[1] = r_start_y;//y

	//开启邻域循环
	while (break_flag--)
	{

		//左边
		for (i = 0; i < 8; i++)//传递8F坐标
		{
			search_filds_l[i][0] = center_point_l[0] + seeds_l[i][0];//x
			search_filds_l[i][1] = center_point_l[1] + seeds_l[i][1];//y
		}
		//中心坐标点填充到已经找到的点内
		points_l[l_data_statics][0] = center_point_l[0];//x
		points_l[l_data_statics][1] = center_point_l[1];//y
		l_data_statics++;//索引加一

		//右边
		for (i = 0; i < 8; i++)//传递8F坐标
		{
			search_filds_r[i][0] = center_point_r[0] + seeds_r[i][0];//x
			search_filds_r[i][1] = center_point_r[1] + seeds_r[i][1];//y
		}
		//中心坐标点填充到已经找到的点内
		points_r[r_data_statics][0] = center_point_r[0];//x
		points_r[r_data_statics][1] = center_point_r[1];//y

		index_l = 0;//先清零，后使用
		for (i = 0; i < 8; i++)
		{
			temp_l[i][0] = 0;//先清零，后使用
			temp_l[i][1] = 0;//先清零，后使用
		}

		//左边判断
		for (i = 0; i < 8; i++)
		{
			if (image[search_filds_l[i][1]][search_filds_l[i][0]] == 0
				&& image[search_filds_l[(i + 1) & 7][1]][search_filds_l[(i + 1) & 7][0]] == 255)
			{
				temp_l[index_l][0] = search_filds_l[(i)][0];
				temp_l[index_l][1] = search_filds_l[(i)][1];
				index_l++;
				dir_l[l_data_statics - 1] = (i);//记录生长方向
			}

			if (index_l)
			{
				//更新坐标点
				center_point_l[0] = temp_l[0][0];//x
				center_point_l[1] = temp_l[0][1];//y
				for (j = 0; j < index_l; j++)
				{
					if (center_point_l[1] > temp_l[j][1])
					{
						center_point_l[0] = temp_l[j][0];//x
						center_point_l[1] = temp_l[j][1];//y
					}
				}
			}

		}
		if ((points_r[r_data_statics][0] == points_r[r_data_statics - 1][0] && points_r[r_data_statics][0] == points_r[r_data_statics - 2][0]
			&& points_r[r_data_statics][1] == points_r[r_data_statics - 1][1] && points_r[r_data_statics][1] == points_r[r_data_statics - 2][1])
			|| (points_l[l_data_statics - 1][0] == points_l[l_data_statics - 2][0] && points_l[l_data_statics - 1][0] == points_l[l_data_statics - 3][0]
				&& points_l[l_data_statics - 1][1] == points_l[l_data_statics - 2][1] && points_l[l_data_statics - 1][1] == points_l[l_data_statics - 3][1]))
		{
			//printf("三次进入同一个点，退出\n");
			break;
		}
		if (my_abs(points_r[r_data_statics][0] - points_l[l_data_statics - 1][0]) < 2
			&& my_abs(points_r[r_data_statics][1] - points_l[l_data_statics - 1][1] < 2)
			)
		{
			//printf("\n左右相遇退出\n");	
			*hightest = (points_r[r_data_statics][1] + points_l[l_data_statics - 1][1]) >> 1;//取出最高点
			//printf("\n在y=%d处退出\n",*hightest);
			break;
		}
		if ((points_r[r_data_statics][1] < points_l[l_data_statics - 1][1]))
		{
			printf("\n如果左边比右边高了，左边等待右边\n");
			continue;//如果左边比右边高了，左边等待右边
		}
		if (dir_l[l_data_statics - 1] == 7
			&& (points_r[r_data_statics][1] > points_l[l_data_statics - 1][1]))//左边比右边高且已经向下生长了
		{
			//printf("\n左边开始向下了，等待右边，等待中... \n");
			center_point_l[0] = points_l[l_data_statics - 1][0];//x
			center_point_l[1] = points_l[l_data_statics - 1][1];//y
			l_data_statics--;
		}
		r_data_statics++;//索引加一

		index_r = 0;//先清零，后使用
		for (i = 0; i < 8; i++)
		{
			temp_r[i][0] = 0;//先清零，后使用
			temp_r[i][1] = 0;//先清零，后使用
		}

		//右边判断
		for (i = 0; i < 8; i++)
		{
			if (image[search_filds_r[i][1]][search_filds_r[i][0]] == 0
				&& image[search_filds_r[(i + 1) & 7][1]][search_filds_r[(i + 1) & 7][0]] == 255)
			{
				temp_r[index_r][0] = search_filds_r[(i)][0];
				temp_r[index_r][1] = search_filds_r[(i)][1];
				index_r++;//索引加一
				dir_r[r_data_statics - 1] = (i);//记录生长方向
				//printf("dir[%d]:%d\n", r_data_statics - 1, dir_r[r_data_statics - 1]);
			}
			if (index_r)
			{

				//更新坐标点
				center_point_r[0] = temp_r[0][0];//x
				center_point_r[1] = temp_r[0][1];//y
				for (j = 0; j < index_r; j++)
				{
					if (center_point_r[1] > temp_r[j][1])
					{
						center_point_r[0] = temp_r[j][0];//x
						center_point_r[1] = temp_r[j][1];//y
					}
				}

			}
		}


	}


	//取出循环次数
	*l_stastic = l_data_statics;
	*r_stastic = r_data_statics;

}

// 获取左边界
static void get_left(uint16 total_L)
{
	uint8 i = 0;
	uint16 j = 0;
	uint8 h = 0;
	//初始化
	for (i = 0;i < image_h;i++)
	{
		l_border[i] = border_min;
	}
	h = image_h - 2;
	//左边
	for (j = 0; j < total_L; j++)
	{
		//printf("%d\n", j);
		if (points_l[j][1] == h)
		{
			l_border[h] = points_l[j][0] + 1;
		}
		else continue; //每行只取一个点，没到下一行就不记录
		h--;
		if (h == 0)
		{
			break;//到最后一行退出
		}
	}
}

// 获取右边界
static void get_right(uint16 total_R)
{
	uint8 i = 0;
	uint16 j = 0;
	uint8 h = 0;
	for (i = 0; i < image_h; i++)
	{
		r_border[i] = border_max;//右边线初始化放到最右边，左边线放到最左边，这样八邻域闭合区域外的中线就会在中间，不会干扰得到的数据
	}
	h = image_h - 2;
	//右边
	for (j = 0; j < total_R; j++)
	{
		if (points_r[j][1] == h)
		{
			r_border[h] = points_r[j][0] - 1;
		}
		else continue;//每行只取一个点，没到下一行就不记录
		h--;
		if (h == 0)break;//到最后一行退出
	}
}

// 形态学滤波 ， 简单来说就是膨胀和腐蚀的思想
static void image_filter(uint8(*bin_image)[image_w])//形态学滤波，简单来说就是膨胀和腐蚀的思想
{
	uint16 i, j;
	uint32 num = 0;


	for (i = 1; i < image_h - 1; i++)
	{
		for (j = 1; j < (image_w - 1); j++)
		{
			//统计八个方向的像素值
			num =
				bin_image[i - 1][j - 1] + bin_image[i - 1][j] + bin_image[i - 1][j + 1]
				+ bin_image[i][j - 1] + bin_image[i][j + 1]
				+ bin_image[i + 1][j - 1] + bin_image[i + 1][j] + bin_image[i + 1][j + 1];


			if (num >= threshold_max && bin_image[i][j] == 0)
			{

				bin_image[i][j] = 255;//白  可以搞成宏定义，方便更改

			}
			if (num <= threshold_min && bin_image[i][j] == 255)
			{

				bin_image[i][j] = 0;//黑

			}

		}
	}

}

// 给图像画一个黑框
static void image_draw_rectan(uint8(*image)[image_w])
{
	for (int i = 0; i < image_h; i++)
	{
		image[i][0] = 0;
		image[i][1] = 0;
		image[i][image_w - 1] = 0;
		image[i][image_w - 2] = 0;

	}
	for (int i = 0; i < image_w; i++)
	{
		image[0][i] = 0;
		image[1][i] = 0;
		//image[image_h-1][i] = 0;

	}
}

// 最小二乘法
static float Slope_Calculate(uint8 begin, uint8 end, uint8* border)
{
	float xsum = 0, ysum = 0, xysum = 0, x2sum = 0;
	int16 i = 0;
	float result = 0;
	static float resultlast;

	for (i = begin; i < end; i++)
	{
		xsum += i;
		ysum += border[i];
		xysum += i * (border[i]);
		x2sum += i * i;

	}
	if ((end - begin) * x2sum - xsum * xsum) //判断除数是否为零
	{
		result = ((end - begin) * xysum - xsum * ysum) / ((end - begin) * x2sum - xsum * xsum);
		resultlast = result;
	}
	else
	{
		result = resultlast;
	}
	return result;
}

// 计算斜率截距
static void calculate_s_i(uint8 start, uint8 end, uint8* border, float* slope_rate, float* intercept)
{
	uint16 i, num = 0;
	uint16 xsum = 0, ysum = 0;
	float y_average, x_average;

	num = 0;
	xsum = 0;
	ysum = 0;
	y_average = 0;
	x_average = 0;
	for (i = start; i < end; i++)
	{
		xsum += i;
		ysum += border[i];
		num++;
	}

	//计算各个平均数
	if (num)
	{
		x_average = (float)(xsum / num);
		y_average = (float)(ysum / num);

	}

	/*计算斜率*/
	*slope_rate = Slope_Calculate(start, end, border);//斜率
	*intercept = y_average - (*slope_rate) * x_average;//截距
}

// 十字补线函数
static  void cross_fill(uint8(*image)[image_w], uint8* l_border, uint8* r_border, uint16 total_num_l, uint16 total_num_r,
	uint16* dir_l, uint16* dir_r, uint16(*points_l)[2], uint16(*points_r)[2])
{
	uint8 i;
	uint8 break_num_l = 0;
	uint8 break_num_r = 0;
	uint8 start, end;
	float slope_l_rate = 0, intercept_l = 0;
	//出十字
	for (i = 1; i < total_num_l; i++)
	{
		if (dir_l[i - 1] == 4 && dir_l[i] == 4 && dir_l[i + 3] == 6 && dir_l[i + 5] == 6 && dir_l[i + 7] == 6)
		{
			break_num_l = points_l[i][1];//传递y坐标
			printf("brea_knum-L:%d\n", break_num_l);
			printf("I:%d\n", i);
			printf("十字标志位：1\n");
			break;
		}
	}
	for (i = 1; i < total_num_r; i++)
	{
		if (dir_r[i - 1] == 4 && dir_r[i] == 4 && dir_r[i + 3] == 6 && dir_r[i + 5] == 6 && dir_r[i + 7] == 6)
		{
			break_num_r = points_r[i][1];//传递y坐标
			printf("brea_knum-R:%d\n", break_num_r);
			printf("I:%d\n", i);
			printf("十字标志位：1\n");
			break;
		}
	}
	if (break_num_l && break_num_r && image[image_h - 1][4] && image[image_h - 1][image_w - 4])//两边生长方向都符合条件
	{
		//计算斜率
		start = break_num_l - 15;
		start = limit_a_b(start, 0, image_h);
		end = break_num_l - 5;
		calculate_s_i(start, end, l_border, &slope_l_rate, &intercept_l);
		//printf("slope_l_rate:%d\nintercept_l:%d\n", slope_l_rate, intercept_l);
		for (i = break_num_l - 5; i < image_h - 1; i++)
		{
			l_border[i] = slope_l_rate * (i)+intercept_l;//y = kx+b
			l_border[i] = limit_a_b(l_border[i], border_min, border_max);//限幅
		}

		//计算斜率
		start = break_num_r - 15;//起点
		start = limit_a_b(start, 0, image_h);//限幅
		end = break_num_r - 5;//终点
		calculate_s_i(start, end, r_border, &slope_l_rate, &intercept_l);
		//printf("slope_l_rate:%d\nintercept_l:%d\n", slope_l_rate, intercept_l);
		for (i = break_num_r - 5; i < image_h - 1; i++)
		{
			r_border[i] = slope_l_rate * (i)+intercept_l;
			r_border[i] = limit_a_b(r_border[i], border_min, border_max);
		}


	}

}

static Mat Array_to_Mat(uint8(*image)[image_w])
{
	Mat img(image_h, image_w, CV_8UC1, Scalar(0));
	for (int i = 0; i < image_h; i++)
	{
		for (int j = 0; j < image_w; j++)
		{
			img.at<uchar>(i, j) = image[i][j];
		}
	}
	return img;

}

static void myImshow(const String& winname, InputArray mat)
{
	// imshow(winname, mat);
}

/*
static void fitLineAndCalculateAngle(const std::vector<cv::Point>& points, double& angle, double& rSquared) {
	if (points.empty()) {
		std::cerr << "点集为空！" << std::endl;
		return;
	}

	// 提取 y 和 x 坐标
	std::vector<double> yCoords, xCoords;
	for (const auto& point : points) {
		yCoords.push_back(point.y);
		xCoords.push_back(point.x);
	}

	// 计算必要的和
	double sumY = 0, sumX = 0, sumXY = 0, sumY2 = 0;
	for (size_t i = 0; i < points.size(); ++i) {
		sumY += yCoords[i];
		sumX += xCoords[i];
		sumXY += yCoords[i] * xCoords[i];
		sumY2 += yCoords[i] * yCoords[i];
	}

	// 计算斜率 k 和截距 b
	double n = points.size();
	double k = (n * sumXY - sumY * sumX) / (n * sumY2 - sumY * sumY);
	double b = (sumX - k * sumY) / n;

	// 计算拟合度 R^2
	double meanX = sumX / n;
	double ssTot = 0, ssRes = 0;
	for (size_t i = 0; i < points.size(); ++i) {
		double predictedX = k * yCoords[i] + b;
		ssTot += (xCoords[i] - meanX) * (xCoords[i] - meanX);
		ssRes += (xCoords[i] - predictedX) * (xCoords[i] - predictedX);
	}
	rSquared = 1 - (ssRes / ssTot);

	// 计算中线与垂直方向的夹角
	angle = std::atan(k) * 180 / CV_PI; // 转换为角度
}
*/

static void fitLineAndCalculateAngle(const std::vector<cv::Point>& points, double& angle, double& rSquared) {
	if (points.empty() || points.size() == 1) {
		std::cerr << "点集数据不足，无法拟合直线！" << std::endl;
		return;
	}

	// 检查是否所有点的 y 坐标相同
	bool allYSame = true;
	double firstY = points[0].y;
	for (const auto& point : points) {
		if (point.y != firstY) {
			allYSame = false;
			break;
		}
	}
	if (allYSame) {
		angle = 0.0;
		rSquared = 1.0; // 完全拟合
		return;
	}

	// 检查是否所有点的 x 坐标相同
	bool allXSame = true;
	double firstX = points[0].x;
	for (const auto& point : points) {
		if (point.x != firstX) {
			allXSame = false;
			break;
		}
	}
	if (allXSame) {
		angle = 90.0;
		rSquared = 1.0; // 完全拟合
		return;
	}

	// 提取 y 和 x 坐标
	std::vector<double> yCoords, xCoords;
	for (const auto& point : points) {
		yCoords.push_back(point.y);
		xCoords.push_back(point.x);
	}

	// 计算必要的和
	double sumY = 0, sumX = 0, sumXY = 0, sumY2 = 0;
	for (size_t i = 0; i < points.size(); ++i) {
		sumY += yCoords[i];
		sumX += xCoords[i];
		sumXY += yCoords[i] * xCoords[i];
		sumY2 += yCoords[i] * yCoords[i];
	}

	// 计算斜率 k 和截距 b
	double n = points.size();
	double denominator = (n * sumY2 - sumY * sumY);
	if (denominator == 0) {
		std::cerr << "无法计算斜率，分母为 0！" << std::endl;
		return;
	}
	double k = (n * sumXY - sumY * sumX) / denominator;
	double b = (sumX - k * sumY) / n;

	// 计算拟合度 R^2
	double meanX = sumX / n;
	double ssTot = 0, ssRes = 0;
	for (size_t i = 0; i < points.size(); ++i) {
		double predictedX = k * yCoords[i] + b;
		ssTot += (xCoords[i] - meanX) * (xCoords[i] - meanX);
		ssRes += (xCoords[i] - predictedX) * (xCoords[i] - predictedX);
	}
	if (ssTot == 0) {
		rSquared = 1.0; // 完全拟合
	} else {
		rSquared = 1 - (ssRes / ssTot);
	}

	// 计算中线与垂直方向的夹角
	angle = std::atan(k) * 180 / CV_PI; // 转换为角度
}

static int mapDoubleToInt(double value, double fromLow, double fromHigh, int toLow, int toHigh) {
	// 确保输入值在原始范围内
	if (value < fromLow) {
		value = fromLow;
	} else if (value > fromHigh) {
		value = fromHigh;
	}

	// 计算映射后的值
	double scale = static_cast<double>(toHigh - toLow) / (fromHigh - fromLow);
	int result = static_cast<int>(toLow + (value - fromLow) * scale);

	return result;
}

// 将 320x240 的图像转换为 160x120 的图像
cv::Mat resizeImage(const cv::Mat& inputImage) {
    // 检查输入图像的尺寸是否为 320x240
    if (inputImage.cols != 320 || inputImage.rows != 240) {
        std::cerr << "输入图像的尺寸不是 320x240！" << std::endl;
        return cv::Mat(); // 返回空矩阵
    }

    // 创建目标图像（160x120）
    cv::Mat resizedImage;

    // 调整图像尺寸
    cv::resize(inputImage, resizedImage, cv::Size(160, 120), 0, 0, cv::INTER_LINEAR);

    return resizedImage;
}

static int i2c_send_data(uint8_t i2c_addr, uint8_t *data, uint8_t length) 
{
	int file;
	char filename[20];

	// 打开I2C总线设备文件
	snprintf(filename, sizeof(filename), "/dev/i2c-%d", 0); // 假设使用I2C总线1
	file = open(filename, O_RDWR);
	if (file < 0) {
		perror("Failed to open the i2c bus");
		return -1;
	}

	// 设置I2C从设备地址
	if (ioctl(file, I2C_SLAVE, i2c_addr) < 0) {
		perror("Failed to set I2C slave address");
		close(file);
		return -1;
	}

	// 发送数据
	if (write(file, data, length) != length) {
		perror("Failed to write to the i2c bus");
		close(file);
		return -1;
	}

	// 关闭I2C设备文件
	close(file);
	return 0;
}



int main()
{
	double res_angle, res_rSquared;

	uint8 hightest = 0;//定义一个最高行，tip：这里的最高指的是y值的最小
	
	cv::VideoCapture cap(0);
	cap.set(cv::CAP_PROP_FRAME_WIDTH, 320);
	cap.set(cv::CAP_PROP_FRAME_HEIGHT, 240);
	cap.set(cv::CAP_PROP_FPS, 120);

	if (!cap.isOpened()) {
	cout << "Error opening video stream or file" << endl;
	return -1;
	}

	Mat img,GrayImg,bin_img;
	uint8_t iicData[8] = {0};

	while(1)
	{

		// double tickStart = (double)getTickCount();

		int ret = cap.read(img);

		double tickStart = (double)getTickCount();

		img = resizeImage(img);

		cvtColor(img, GrayImg, COLOR_BGR2GRAY);

		Get_image(GrayImg);

		turn_to_bin();

		// bin_img = Array_to_Mat(bin_image);

		/*提取赛道边界*/
		image_filter(bin_image);//滤波
		image_draw_rectan(bin_image);//预处理
		//清零
		data_stastics_l = 0;
		data_stastics_r = 0;

		if (get_start_point(image_h - 2))//找到起点了，再执行八领域，没找到就一直找
		{
			// printf("正在开始八领域\n");
			search_l_r((uint16)USE_num, bin_image, &data_stastics_l, &data_stastics_r, start_point_l[0], start_point_l[1], start_point_r[0], start_point_r[1], &hightest);
			// printf("八邻域已结束\n");
			// 从爬取的边界线内提取边线 ， 这个才是最终有用的边线
			get_left(data_stastics_l);
			get_right(data_stastics_r);
			//处理函数放这里，不要放到if外面去了，不要放到if外面去了，不要放到if外面去了，重要的事说三遍

		}

		
		std::vector<cv::Point> points(image_h-hightest-1);
		for (int i = hightest; i < image_h - 1; i++)
		{
			points[i-hightest].x = center_line[i];
			points[i-hightest].y = i;
		}
		fitLineAndCalculateAngle(points,res_angle,res_rSquared);
		int send_angle = mapDoubleToInt(res_angle,-50.0,50.0,0,30);
		printf("angle= %f ,R²= %f ,send_angle= %d \n",res_angle,res_rSquared,send_angle);

		iicData[IIC_DATA_DIRECTION] = send_angle;
		i2c_send_data(IIC_ADDR_RECEIVER,iicData,IIC_DATA_LENGTH);
		
		double tickEnd = (double)getTickCount();
		int interval_ms = (((tickEnd - tickStart) / (getTickFrequency())) * 1000);
		printf("完成一帧:%d\t", interval_ms);
	}

	
	printf("程序结束\n");
	return 0;
}









