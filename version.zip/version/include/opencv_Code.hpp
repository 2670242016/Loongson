#pragma once

#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>
#include <math.h>
#include <cmath>		
#include <stdlib.h>
#include "stdio.h"

#define image_w	320	//图像宽度
#define image_h	(240-60)	//图像高度 120-30

#define white_pixel	255
#define black_pixel	0

#define bin_jump_num	1//跳过的点数
#define border_max	image_w-2 //边界最大值
#define border_min	1	//边界最小值	

#define USE_num	image_h*3

#define threshold_max	255*5//此参数可根据自己的需求调节
#define threshold_min	255*2//此参数可根据自己的需求调节

using namespace std;
using namespace cv;

typedef   signed          char int8;
typedef   signed short     int int16;
typedef   signed           int int32;
typedef unsigned          char uint8;
typedef unsigned short     int uint16;
typedef unsigned           int uint32;

#define CAMERA_H  image_h
#define CAMERA_W  image_w
#define OUT_H  image_h
#define OUT_W  image_w
uint8 image_final[OUT_H][OUT_W];//逆变换图像
double map_square[CAMERA_H][CAMERA_W][2];//现实映射
int map_int[OUT_H][OUT_W][2];//图像映射

uint8 original_image[image_h][image_w];
uint8 image_thereshold;//图像分割阈值

uint8 bin_image[image_h][image_w];//图像数组

uint16 start_point_l[2] = { 0 };//左边起点的x，y值
uint16 start_point_r[2] = { 0 };//右边起点的x，y值
uint16 points_l[(uint16)USE_num][2] = { {  0 } };//左线
uint16 points_r[(uint16)USE_num][2] = { {  0 } };//右线
uint16 dir_r[(uint16)USE_num] = { 0 };//用来存储右边生长方向
uint16 dir_l[(uint16)USE_num] = { 0 };//用来存储左边生长方向

uint16 data_stastics_l = 0;//统计左边找到点的个数
uint16 data_stastics_r = 0;//统计右边找到点的个数
uint16 hightest = 0;//最高点

uint16 l_border[image_h];//左线数组
uint16 r_border[image_h];//右线数组
uint16 center_line[image_h];//中线数组

cv::Point point;

struct ChangePoint {
    int startIndex;  // 突变起始索引
    int endIndex;    // 突变结束索引
    int type;        // 1 表示上升沿，-1 表示下降沿
};


static int my_abs(int value);

static int16 limit_a_b(int16 x, int a, int b);

static uint8 otsuThreshold(uint8* image, uint16 col, uint16 row);

static void turn_to_bin(void);

static uint16 get_start_point(uint16 start_row);

static void search_l_r(uint16 break_flag, uint8(*image)[image_w], uint16* l_stastic, uint16* r_stastic, uint16 l_start_x, 
						uint16 l_start_y, uint16 r_start_x, uint16 r_start_y, uint16* hightest);

static void get_left(uint16 total_L);

static void get_right(uint16 total_R);

static void image_filter(uint8(*bin_image)[image_w]);

static void image_draw_rectan(uint8(*image)[image_w]);

static Mat Array_to_Mat(uint8(*image)[image_w]);

static void myImshow(const String& winname, InputArray mat);

static Mat er_zhi(Mat imgxiu);

static int mapDoubleToInt(double value, double fromLow, double fromHigh, int toLow, int toHigh);

cv::Mat resizeImage(const cv::Mat& inputImage);

static void fitLineAndCalculateAngle(const std::vector<cv::Point>& points, double& angle, double& rSquared);

void printArrayAsCSV(const uint16 a[],size_t size);

void filterData(uint16* arr, int size);

void findChangePoints(uint16* data, int size, struct ChangePoint** changePoints, int* changeCount, int threshold);

void cropImage(cv::Mat& image, int height);

void ni_tou();

vector<float> calculateCurvature(const vector<Point>& points);

float calculateServoAngle(const vector<float>& curvature, float baseAngle = 15.0f);

void servodegree(float degree);




