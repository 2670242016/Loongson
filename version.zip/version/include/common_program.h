#ifndef _COMMON_PROGRAM_H
#define _COMMON_PROGRAM_H

// src
#include "path.h"

// lib
#include "libdata_process.h"
#include "libdata_store.h"
#include "libimage_process.h"

#endif