#pragma once

struct PID
{
  float target = 0;					      //目标量
  float present;					        //当前量

  float departure;					      //偏差量
  float departure_previous;			  //上一个偏差量

  float P;					              //比例P
  float I;				                //积分I
  float D;				                //微分D

  float Kp;			              //比例系数
  float Ki;				                //积分系数
  float Kd;			                  //微分系数

  float Res;					            //执行量

  float percentageMin   = -300;		//比例P最小值
  float percentageMax   =  300;		//比例P最大值
  float integralMin     = -800;		//积分I最小值
  float integralMax     =  800;		//积分I最大值
  float differentialMin = -200;	  //微分D最小值
  float differentialMax =  200;	  //微分D最大值
  float executeMin      = -200;		//执行量最小值
  float executeMax      =  200;		//执行量最大值
  float targetMin       = -720;		//执行量最小值
  float targetMax       =  720;		//执行量最大值
};



