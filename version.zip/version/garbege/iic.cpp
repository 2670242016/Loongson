#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/i2c-dev.h>
#include <stdint.h>

int i2c_send_data(uint8_t i2c_addr, uint8_t *data, uint8_t length) {
    int file;
    char filename[20];

    // 打开I2C总线设备文件
    snprintf(filename, sizeof(filename), "/dev/i2c-%d", 0); // 假设使用I2C总线1
    file = open(filename, O_RDWR);
    if (file < 0) {
        perror("Failed to open the i2c bus");
        return -1;
    }

    // 设置I2C从设备地址
    if (ioctl(file, I2C_SLAVE, i2c_addr) < 0) {
        perror("Failed to set I2C slave address");
        close(file);
        return -1;
    }

    // 发送数据
    if (write(file, data, length) != length) {
        perror("Failed to write to the i2c bus");
        close(file);
        return -1;
    }

    // 关闭I2C设备文件
    close(file);
    return 0;
}

int main(int argc, char *argv[]) {
    uint8_t i2c_addr = 0x08; 
    uint8_t data[8] = {0};
    uint8_t length = sizeof(data);

    


    i2c_send_data(i2c_addr, data, length);

    return 0;
}
