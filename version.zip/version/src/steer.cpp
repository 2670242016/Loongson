#include "steer.h"
#include "LQ_GTIM_PWM.hpp"

GtimPwm ServoPWM1(88, 2, LS_GTIM_INVERSED, 2000000 - 1, 83000); // TIM2_CH2 GPIO88  50000-90000
PID_Datatypedef SteerPIDdata;    //舵机的PID参数

float iError,//当前误差   原来是int类型 5.23更改为float
      SteerErr,
      SteerErr_pre;
int PWM;

void init_pwm()
{   
    ServoPWM1.Enable();
}

void export_pwm(const char* pwmchip)
{
}


void set_period(const char* pwmchip, uint32 period_10ns)
{
}


void set_polarity(const char* pwmchip, const char* polarity_i)
{
}

void enable_pwm(const char* pwmchip)
{
}


void set_duty_cycle(const char* pwmchip, uint32 duty_cycle_10ns)
{
}


void SteerControl(int dir, int angle)
{
    int real_angle = dir*angle;
    uint32 h_time = 72000+(real_angle*2000000/1100);

    ServoPWM1.SetDutyCycle(h_time);
}

void SteerControl_real(uint32 h_time)
{
    
}