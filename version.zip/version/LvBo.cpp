#include <stdio.h>
#include <stdlib.h>


#define SUANFA 4

#include <stdio.h>
#include <stdlib.h>

#include <stdio.h>
#include <stdlib.h>

#include <iostream>
#include <vector>
#include <algorithm>

// 中值滤波函数
void medianFilter(std::vector<int>& data, int windowSize) {
    std::vector<int> temp = data;  // 复制原始数据
    int halfWin = windowSize / 2;

    for (size_t i = halfWin; i < data.size() - halfWin; ++i) {
        std::vector<int> window(data.begin() + i - halfWin, data.begin() + i + halfWin + 1);
        std::sort(window.begin(), window.end());
        temp[i] = window[window.size() / 2];  // 取中值
    }

    data = temp;  // 更新原始数据
}

// 峰值检测与去除（简单的局部极值检查）
void removePeaks(std::vector<int>& data, int threshold) {
    std::vector<int> temp = data;  // 复制数据
    for (size_t i = 1; i < data.size() - 1; ++i) {
        if (data[i] > data[i - 1] + threshold && data[i] > data[i + 1] + threshold) {
            temp[i] = (data[i - 1] + data[i + 1]) / 2;  // 用邻居均值替代
        }
    }
    data = temp;
}

// 主要滤波函数
void filterData(int* arr, int size) {
    if (size < 3) return;  // 数据太短无法滤波

    std::vector<int> data(arr, arr + size);

    // 先进行中值滤波，去除 ±1 震荡
    medianFilter(data, 3);

    // 再去除峰值
    removePeaks(data, 2);  // 设定阈值 2，去除明显的孤立峰

    // 复制回原始数组
    for (int i = 0; i < size; ++i) {
        arr[i] = data[i];
    }
}

int main() {
    int data[] = {
        3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,5,5,5,5,6,5,6,5,5,6,5,5,5,6,5,5,6,5,5,5,6,5,5,2,6,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3,4,4,4,4,4,4,4,4,4,5,6,6,6,6,6,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5,6,5,5,5,5,6,6,5,6,6,6,6,5,6,6,2,2,2,2,2,2,2,2,2,2,3,2,2,3,5,6,6,6,5,6,6,6,6,6,6,6,6,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6
       };
    int size = sizeof(data) / sizeof(data[0]);

    std::cout << "原始数据: ";
    for (int i = 0; i < size; ++i) std::cout << data[i] << " ";
    std::cout << std::endl;

    filterData(data, size);

    std::cout << "滤波后数据: ";
    for (int i = 0; i < size; ++i) std::cout << data[i] << " ";
    std::cout << std::endl;

    return 0;
}





#if SUANFA == 3
// 平滑数据的函数
void smoothData(const int* data, int* smoothedData, int dataSize, int windowSize) {
    for (int i = 0; i < dataSize; ++i) {
        int sum = 0;
        int count = 0;

        // 计算窗口内的平均值
        for (int j = -windowSize; j <= windowSize; ++j) {
            if (i + j >= 0 && i + j < dataSize) {
                sum += data[i + j];
                count++;
            }
        }

        // 将平均值作为平滑后的值
        smoothedData[i] = sum / count;
    }
}

int main() {
    // 原始数据
    int data[] = {
        3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,5,5,5,5,6,5,6,5,5,6,5,5,5,6,5,5,6,5,5,5,6,5,5,2,6,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3,4,4,4,4,4,4,4,4,4,5,6,6,6,6,6,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5,6,5,5,5,5,6,6,5,6,6,6,6,5,6,6,2,2,2,2,2,2,2,2,2,2,3,2,2,3,5,6,6,6,5,6,6,6,6,6,6,6,6,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6
       };
    int dataSize = sizeof(data) / sizeof(data[0]); // 计算数据长度

    // 分配内存存储平滑后的数据
    int* smoothedData = (int*)malloc(dataSize * sizeof(int));
    if (smoothedData == NULL) {
        printf("内存分配失败！\n");
        return 1;
    }

    int windowSize = 2; // 窗口大小
    smoothData(data, smoothedData, dataSize, windowSize);

    // 输出平滑后的数据
    printf("平滑后的数据：\n");
    for (int i = 0; i < dataSize; ++i) {
        printf("%d ", smoothedData[i]);
    }
    printf("\n");

    // 释放内存
    free(smoothedData);

    return 0;
}
#endif


#if SUANFA == 2


// 限幅滤波函数
void limitFilter(const int* data, int* filteredData, int dataSize, int threshold) {
    filteredData[0] = data[0]; // 第一个数据保持不变

    for (int i = 1; i < dataSize; ++i) {
        int diff = abs(data[i] - filteredData[i - 1]); // 计算当前点与前一个点的差值

        // 如果差值超过阈值，则限制变化幅度
        if (diff > threshold) {
            if (data[i] > filteredData[i - 1]) {
                filteredData[i] = filteredData[i - 1] + threshold; // 限制正向变化
            } else {
                filteredData[i] = filteredData[i - 1] - threshold; // 限制负向变化
            }
        } else {
            filteredData[i] = data[i]; // 差值在阈值内，直接使用原始数据
        }
    }
}

int main() {
    // 原始数据
    int data[] = {
        3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,5,5,5,5,6,5,6,5,5,6,5,5,5,6,5,5,6,5,5,5,6,5,5,2,6,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3,4,4,4,4,4,4,4,4,4,5,6,6,6,6,6,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5,6,5,5,5,5,6,6,5,6,6,6,6,5,6,6,2,2,2,2,2,2,2,2,2,2,3,2,2,3,5,6,6,6,5,6,6,6,6,6,6,6,6,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6
       };
    int dataSize = sizeof(data) / sizeof(data[0]); // 计算数据长度

    // 分配内存存储滤波后的数据
    int* filteredData = (int*)malloc(dataSize * sizeof(int));
    if (filteredData == NULL) {
        printf("内存分配失败！\n");
        return 1;
    }

    int threshold = 1; // 限幅滤波的阈值
    limitFilter(data, filteredData, dataSize, threshold);

    // 输出滤波后的数据
    printf("滤波后的数据：\n");
    for (int i = 0; i < dataSize; ++i) {
        printf("%d ", filteredData[i]);
    }
    printf("\n");

    // 释放内存
    free(filteredData);

    return 0;
}



#endif






#if SUANFA == 1
// 比较函数，用于排序
int compare(const void* a, const void* b) {
    return (*(int*)a - *(int*)b);
}

// 中值滤波函数
void medianFilter(const int* data, int* filteredData, int dataSize, int windowSize) {
    for (int i = 0; i < dataSize; ++i) {
        int window[windowSize * 2 + 1]; // 窗口数组
        int count = 0;

        // 填充窗口数组
        for (int j = -windowSize; j <= windowSize; ++j) {
            if (i + j >= 0 && i + j < dataSize) {
                window[count++] = data[i + j];
            }
        }

        // 对窗口数组排序
        qsort(window, count, sizeof(int), compare);

        // 取中值作为滤波后的值
        filteredData[i] = window[count / 2];
    }
}

int main() {
    // 原始数据
    int data[] = {
        3,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,4,5,5,5,5,6,5,6,5,5,6,5,5,5,6,5,5,6,5,5,5,6,5,5,2,6,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,3,4,4,4,4,4,4,4,4,4,5,6,6,6,6,6,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,5,6,5,5,5,5,6,6,5,6,6,6,6,5,6,6,2,2,2,2,2,2,2,2,2,2,3,2,2,3,5,6,6,6,5,6,6,6,6,6,6,6,6,5,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6,6
        };
    int dataSize = sizeof(data) / sizeof(data[0]); // 计算数据长度

    // 分配内存存储滤波后的数据
    int* filteredData = (int*)malloc(dataSize * sizeof(int));
    if (filteredData == NULL) {
        printf("内存分配失败！\n");
        return 1;
    }

    int windowSize = 2; // 中值滤波的窗口大小
    medianFilter(data, filteredData, dataSize, windowSize);

    // 输出滤波后的数据
    printf("滤波后的数据：\n");
    for (int i = 0; i < dataSize; ++i) {
        printf("%d ", filteredData[i]);
    }
    printf("\n");

    // 释放内存
    free(filteredData);

    return 0;
}
#endif

